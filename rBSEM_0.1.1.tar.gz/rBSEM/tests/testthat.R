library(testthat)
library(rBSEM)

test_check("rBSEM")