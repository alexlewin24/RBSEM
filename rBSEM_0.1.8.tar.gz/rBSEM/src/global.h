#ifndef GLOBAL
#define GLOBAL

#ifdef _OPENMP
#include <omp.h>
#endif

#include <vector>
#include <random>
#include <armadillo> // include this globally

#endif
