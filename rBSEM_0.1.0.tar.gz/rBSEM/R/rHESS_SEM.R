#' rBSEM -- Bayesian Structural Equation Models Regression
#' @title rHESS_SEM
#' @description
#' Run a simple SEM Bayesian sampler
#' IMPORTANT NOTE: outFilePath must exists, otherwise no output is going to be written.
#' You can make sure of its existence by using base::dir.create(outFilePath) from R
#' @name rHESS_SEM
#' @param inFile path to data file
#' @param blocks list of blocks in the model
#' @param varType variable type for each column in the data file
#' @param outFilePath path to where the output is to be written
#' @param nIter number of iterations
#' @param nChains number of parallel chains to run
#' @param seed pRNG seed
#' @param method \deqn{\gamma}{gamma} sampling method, where 0=\deqn{MC^2}{MC^3} and 1=Thompson -sampling-inspired novel method
#' @examples
#' rHESS_SEM(inFile="tmp/sem_data.txt",outFilePath="tmp/",nIter=200)
#' 
#' @export
rHESS_SEM = function(inFile, blocks=NULL, varType=NULL, outFilePath="", nIter,  nChains=1, seed=0, method=0)
{
  
  dir.create("tmp")
  data(sample_SEM)

  # default varType
  if(is.null(varType)){
    varType = rep(0,ncol(sample_SEM))
  }
  
  if(is.null(blocks)){
    blocks = list(c(1),2:ncol(sample_SEM))
  }
  
  write.table(sample_sem,"tmp/sem_data.txt",row.names = FALSE,col.names = FALSE)
  
  rHESS_SEM_internal(inFile,outFilePath,nIter,  nChains, seed, method)
  unlink("tmp", recursive=TRUE)
}