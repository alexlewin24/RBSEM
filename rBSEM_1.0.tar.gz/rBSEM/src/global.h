
#ifndef GLOBAL
#define GLOBAL

#include <omp.h>
#include <vector>
#include <random>
#include <armadillo> // include this globally

#endif
